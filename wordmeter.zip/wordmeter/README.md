# WordMeter

A small, dependency-free Python command-line tool that counts words, characters,
and lines, and estimates reading time. Text stays on your computer.

## Requirements

Python 3.9 or newer. No packages to install.

## Usage

```sh
python wordmeter.py notes.txt
python wordmeter.py notes.txt --json
```

You can also pipe text into the tool:

```sh
echo "Hello open source" | python wordmeter.py --json
```

Files must use UTF-8. Reading time rounds up at 200 words per minute.
Words are Unicode word sequences, allowing internal apostrophes and hyphens;
this is a simple heuristic rather than language-specific segmentation.
Characters include whitespace. Empty input has zero lines.
The whole input is read into memory, so use it for ordinary text files.

## Contributing

Bug reports and pull requests are welcome. Include a small sample input and
the expected output when reporting a counting issue.

## License

MIT; see LICENSE.
