"""Count words, characters, and estimated reading time in UTF-8 text."""

import argparse
import json
import math
from pathlib import Path
import re
import sys


def analyze(text):
    words = len(re.findall(r"\b\w+(?:['’-]\w+)*\b", text))
    return {
        "words": words,
        "characters": len(text),
        "lines": len(text.splitlines()),
        "reading_minutes": math.ceil(words / 200),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("file", nargs="?", type=Path, help="UTF-8 file; otherwise read stdin")
    parser.add_argument("--json", action="store_true", help="Print JSON")
    args = parser.parse_args()
    try:
        text = args.file.read_text(encoding="utf-8") if args.file else sys.stdin.read()
    except (OSError, UnicodeError) as error:
        parser.exit(1, f"wordmeter: {error}\n")
    stats = analyze(text)
    if args.json:
        print(json.dumps(stats, indent=2))
    else:
        for key, value in stats.items():
            print(f"{key.replace('_', ' ').capitalize()}: {value}")


if __name__ == "__main__":
    main()
